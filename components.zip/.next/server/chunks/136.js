"use strict";
exports.id = 136;
exports.ids = [136];
exports.modules = {

/***/ 2136:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "A": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "tailwind-styled-components"
var external_tailwind_styled_components_ = __webpack_require__(4191);
var external_tailwind_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_tailwind_styled_components_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/footer/footer.tsx


const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: " flex items-center h-12 border-color border-t",
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: "pl-6 w-full max-w-lg",
            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "grid grid-cols-3 divide-x divide-[#1E2D3D]",
                children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: "text-[#607B96]",
                    children: "find me in:"
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./components/header/header.style.tsx


const HeaderContainer = (external_tailwind_styled_components_default()).header`flex-row-reverse md:flex-row relative flex border-color items-center justify-between w-full border-b`;
const Contact = (external_tailwind_styled_components_default()).div`text-[#607B96] min-w-max text-right  w-full max-w-[170px] text-center  hidden md:block`;
const LogoStyle = (external_tailwind_styled_components_default()).div`text-[#607B96] min-w-max w-auto  max-w-xs lg:w-full pl-4 md:px-6 py-4`;
const NavUl = (external_tailwind_styled_components_default()).ul`header_menu grid grid-cols-3 divide-x divide-[#1E2D3D]`;

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/svg/burger.tsx


const Burger = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "18",
        height: "16",
        viewBox: "0 0 18 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M0 0H18V2H0V0ZM0 7H18V9H0V7ZM0 14H18V16H0V14Z",
            fill: "#607B96"
        })
    });
};

;// CONCATENATED MODULE: ./components/svg/close.tsx


const CloseMenu = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "16",
        height: "16",
        viewBox: "0 0 16 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M8 6.2225L14.2225 0L16 1.7775L9.7775 8L16 14.2225L14.2225 16L8 9.7775L1.7775 16L0 14.2225L6.2225 8L0 1.7775L1.7775 0L8 6.2225Z",
            fill: "#607B96"
        })
    });
};

;// CONCATENATED MODULE: ./components/header/mobileMenu.tsx




const MobileMenu = ({ onClick , toggleStatus  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        onClick: onClick,
        className: "pr-4 md:hidden",
        children: toggleStatus !== true ? /*#__PURE__*/ jsx_runtime_.jsx(Burger, {}) : /*#__PURE__*/ jsx_runtime_.jsx(CloseMenu, {})
    });
};

;// CONCATENATED MODULE: ./components/header/index.tsx
// import { MobileMenu } from "../../menu/mobileMenu";






const Header = ()=>{
    let MenuList = [
        "_hello",
        "_about-me",
        "_codebase"
    ];
    const { 0: toggle , 1: setToggle  } = (0,external_react_.useState)(false);
    const { 0: MenuHide , 1: setMenuHide  } = (0,external_react_.useState)("hidden");
    const router = (0,router_.useRouter)();
    function showHideMenu(status) {
        if (status) {
            setMenuHide("");
        } else {
            setMenuHide("hidden");
        }
        setToggle(status);
    }
    let activeBg = toggle ? "bg-[#011627]" : "";
    function Menu({ MenuList  }) {
        let route = router.pathname;
        let url = "";
        return MenuList.map((val, key)=>{
            if (route === "/") {
                route = MenuList[0];
            }
            if (val === MenuList[0]) {
                url = "/";
            } else {
                url = val;
            }
            let active = route.lastIndexOf(val) > -1 ? "active_li" : "";
            let data_hover = key === 0 ? "" : val;
            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "text-[#607B96] text-base  border-b border-[#1E2D3D] text-center " + active,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "botton_line",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: url,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            "data-hover": data_hover,
                            className: "inline-block py-4",
                            children: val
                        })
                    })
                })
            }, key);
        });
    }
    function Logo() {
        return /*#__PURE__*/ jsx_runtime_.jsx(LogoStyle, {
            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/",
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    children: "master-bond"
                })
            })
        });
    }
    function ContactMenu() {
        let active;
        let route = router.pathname;
        if (route === "/_contact-me") {
            active = "active_li";
        }
        return /*#__PURE__*/ jsx_runtime_.jsx(Contact, {
            className: "border-l border-[#1E2D3D] " + active,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "botton_line",
                children: [
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "_contact-me",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "inline-block py-4 ",
                            "data-hover": "_contact-me",
                            children: "_contact-me"
                        })
                    })
                ]
            })
        });
    }
    return(// @ts-ignore
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            " ",
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(HeaderContainer, {
                className: "header_menu " + activeBg,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(MobileMenu, {
                        toggleStatus: toggle,
                        onClick: ()=>showHideMenu(!toggle)
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-row w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Logo, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                                className: "hidden md:block w-full lg:max-w-lg border-color border-x h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(NavUl, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu, {
                                        MenuList: MenuList
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ContactMenu, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                id: "mobile-menu",
                className: `z-10 absolute h-full top-14 w-full ` + MenuHide + " " + activeBg,
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "md:block w-full border-color border-b",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu, {
                        MenuList: MenuList
                    })
                })
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./components/svg/background-mob.tsx


const BackgroundMobile = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "375",
        height: "720",
        viewBox: "0 0 375 720",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                opacity: "0.4",
                filter: "url(#filter0_f_56_2416)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M294.68 557.455L174.223 528.518L123.899 492.106L138.857 396.09L237.639 385.072L236.733 316.517L350.631 285.966L424.001 303.591L377.58 453.436L305.912 472.126L294.68 557.455Z",
                    fill: "#4D5BCE"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                opacity: "0.4",
                filter: "url(#filter1_f_56_2416)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M266.255 221.259L275.554 344.793L256.282 403.843L160.292 418.975L119.585 328.299L54.5936 350.132L-9.3357 251.04L-14.9998 175.796L141.863 174.153L181.58 236.668L266.255 221.259Z",
                    fill: "#43D9AD"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                        id: "filter0_f_56_2416",
                        x: "-50.1006",
                        y: "111.966",
                        width: "648.102",
                        height: "619.489",
                        filterUnits: "userSpaceOnUse",
                        colorInterpolationFilters: "sRGB",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("feFlood", {
                                floodOpacity: "0",
                                result: "BackgroundImageFix"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                mode: "normal",
                                in: "SourceGraphic",
                                in2: "BackgroundImageFix",
                                result: "shape"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                stdDeviation: "87",
                                result: "effect1_foregroundBlur_56_2416"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("filter", {
                        id: "filter1_f_56_2416",
                        x: "-189",
                        y: "0.152924",
                        width: "638.554",
                        height: "592.822",
                        filterUnits: "userSpaceOnUse",
                        colorInterpolationFilters: "sRGB",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("feFlood", {
                                floodOpacity: "0",
                                result: "BackgroundImageFix"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("feBlend", {
                                mode: "normal",
                                in: "SourceGraphic",
                                in2: "BackgroundImageFix",
                                result: "shape"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("feGaussianBlur", {
                                stdDeviation: "87",
                                result: "effect1_foregroundBlur_56_2416"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/layout.tsx







const Layout = ({ children  })=>{
    const router = (0,router_.useRouter)();
    let background = "lg:bg-[#011627]";
    let route = router.pathname;
    if (route === "/") {
        background = "lg:bg-[#01162700]";
    }
    return(//@ts-ignore
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Container, {
        className: background,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
            " ",
            children,
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx(Footer, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "block absolute svg top-0 w-full -z-50 ",
                children: /*#__PURE__*/ jsx_runtime_.jsx(BackgroundMobile, {})
            })
        ]
    }));
};
const Container = (external_tailwind_styled_components_default()).div` relative flex flex-col justify-between h-[96vh] md:h-[95vh] m-3 md:m-4  border-color border rounded-lg  overflow-hidden`;


/***/ })

};
;